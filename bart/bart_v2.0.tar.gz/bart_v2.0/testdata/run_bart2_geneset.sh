bart2 geneset -i genelist.txt -s hg38 --outdir bart2_results 
